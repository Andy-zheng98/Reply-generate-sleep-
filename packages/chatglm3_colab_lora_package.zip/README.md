# ChatGLM3 Colab LoRA 微调包

数据由 `仿真对话语料库_500组.xlsx` 转换：训练集 440 条，验证集 60 条，并按来源记录分组隔离。

在 Google Colab 中：

```bash
pip install -r requirements-single-gpu.txt
python verify_dataset.py
python finetune_hf.py data zai-org/chatglm3-6b configs/lora_sleep.yaml
```

建议使用 Python 3.11 与至少 16GB 显存的 NVIDIA GPU。若显存不足，将配置中的 `max_input_length` 改为 256、`max_output_length` 改为 384。

本语料包含公开医疗问答，只适合研究和内部评估；上线前必须进行医疗、安全、隐私和许可证复核。
