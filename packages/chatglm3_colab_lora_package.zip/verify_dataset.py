#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parent

def load(name):
    result = []
    with (root / "data" / name).open(encoding="utf-8") as handle:
        for line in handle:
            item = json.loads(line)
            assert [x["role"] for x in item["conversations"]] == ["system", "user", "assistant"]
            result.append(item)
    return result

train, dev = load("train.json"), load("dev.json")
assert len(train) == 440 and len(dev) == 60
assert not ({x["group_key"] for x in train} & {x["group_key"] for x in dev})
assert len({x["id"] for x in train + dev}) == 500
print("OK: train=440, dev=60, total=500, group leakage=0")
