#!/usr/bin/env bash
set -euo pipefail
MODEL_ID="${MODEL_ID:-zai-org/chatglm3-6b}"
python finetune_hf.py data "$MODEL_ID" configs/lora_sleep.yaml
